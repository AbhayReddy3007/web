import React from 'react'

function life_at_dr_reddys() {
  return (
    <div>life_at_dr_reddys</div>
  )
}

export default life_at_dr_reddys;