import React from 'react'

function who_we_are() {
  return (
    <div>who_we_are</div>
  )
}

export default who_we_are