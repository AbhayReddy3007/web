import React, { useState } from 'react';
function Home(props) {
  const [count,SetCount]=useState(0);
  const onAdd=(c)=>{
    SetCount(c+1);
  };
  return (
    <div className="home-container">
      <img
        src="https://www.drreddys.com/cms/cms/sites/default/files/2023-05/MicrosoftTeams-image%20%2816%29_2.png"
        alt="Company Logo"
        className="logo"
      />
      <div className="content">
        <p className="intro">
          Welcome to <span className="company-name">Dr. Reddy's</span> — your gateway to quality healthcare.
          <h1>{props.title}</h1>
          <h1 onClick={()=>onAdd(count)}>{count}</h1>
        </p>
      </div>
    </div>
  );
}
export default Home;
