import './App.css';
import React from "react";
import { Route, Link, Routes } from "react-router-dom";

import Home from "../src/pages/home";
import Buissiness from '../src/pages/buissiness';
import Sustainability from '../src/pages/sustainability';
import LifeAtDrReddys from "../src/pages/life_at_dr_reddys";
import WhoWeAre from '../src/pages/who_we_are';

function App() {
  const title="hello"
  return (
    <div className="App">
      <nav>
      <img src="https://upload.wikimedia.org/wikipedia/commons/c/cc/Dr_reddys_logo_%281%29.jpg" alt="Logo" className="logo" />

        <ul className="link-list">
          <Link to="/" className="list">home</Link>
          <Link to="/buissiness" className="list">buissiness</Link>
          <Link to="/sustainability" className="list">sustainability</Link>
          <Link to="/who_we_are" className="list">who_we_are</Link>
          <Link to="/life_at_dr_reddys" className="list">life_at_dr_reddys</Link>
        </ul>
      </nav>

      <Routes>
        <Route path="/" element={<Home title={title} />} />
        <Route path="/buissiness" element={<Buissiness />} />
        <Route path="/sustainability" element={<Sustainability />} />
        <Route path="/who_we_are" element={<WhoWeAre />} />
        <Route path="/life_at_dr_reddys" element={<LifeAtDrReddys />} />
      </Routes>
    </div>
  );
}

export default App;
